
use rhdbs;

#�û�
DROP TABLE IF EXISTS rhdbs.user_info;
create table rhdbs.user_info (
	user_id varchar(30) DEFAULT ' ' NOT NULL,
	pwd varchar(30) DEFAULT ' ' NOT NULL,
	role tinyint(2) DEFAULT 0 NOT NULL,
	note varchar(255) DEFAULT ' ' NOT NULL,
PRIMARY KEY(user_id)
);

#�ͻ���Ϣ
DROP TABLE IF EXISTS rhdbs.cust_info;
CREATE TABLE rhdbs.cust_info (
	cust_id		INT(10)      NOT NULL AUTO_INCREMENT,
	cust_name		VARCHAR(20)  DEFAULT ' ' NOT NULL,
	sex			CHAR(10)     DEFAULT ' ' NOT NULL,
	birthday		DATE,
	hometown		VARCHAR(40)  DEFAULT ' ' NOT NULL,
	id_card		VARCHAR(20)  DEFAULT ' ' NOT NULL,
	address		VARCHAR(250)	 DEFAULT ' ' NOT NULL,
	company		VARCHAR(40)  DEFAULT ' ' NOT NULL,
	phone			VARCHAR(20)  DEFAULT ' ' NOT NULL,
	mobile			VARCHAR(20)  DEFAULT ' ' NOT NULL,
	email			VARCHAR(200) DEFAULT ' ' NOT NULL,
	qq			VARCHAR(20)  DEFAULT ' ' NOT NULL,
	source			VARCHAR(100) DEFAULT ' ' NOT NULL,
	level			CHAR(10)     DEFAULT ' ' NOT NULL,
	ask_flag		CHAR(10)     DEFAULT ' ' NOT NULL,
	ask_time		TIMESTAMP    DEFAULT NOW() NOT NULL,
	deal_flag		CHAR(10)     DEFAULT ' ' NOT NULL,
	note			VARCHAR(512)	 DEFAULT ' ' NOT NULL,
	remind_flag		CHAR(10)     DEFAULT ' ' NOT NULL,
	remind_time		TIMESTAMP    DEFAULT NOW() NOT NULL,
	xczx			VARCHAR(512)	 DEFAULT ' ' NOT NULL,
	dhzx			VARCHAR(512)	 DEFAULT ' ' NOT NULL,
	tbtx			VARCHAR(512)	 DEFAULT ' ' NOT NULL,
	cjjl			VARCHAR(512)	 DEFAULT ' ' NOT NULL,
	photo			BLOB,
	datetime		TIMESTAMP    DEFAULT NOW() NOT NULL,
PRIMARY KEY(cust_id)
);

