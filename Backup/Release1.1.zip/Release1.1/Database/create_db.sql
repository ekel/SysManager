create database rhdbs;



create user 'renhe' identified by 'renhe';

grant all on rhdbs.* to 'renhe'; 


use rhdbs;